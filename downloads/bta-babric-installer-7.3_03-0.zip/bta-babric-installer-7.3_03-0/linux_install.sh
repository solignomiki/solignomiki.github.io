#!/bin/bash

echo "Нажми Enter если у тебя TLauncher"
echo "Иначе, укажи путь до майнкрафта:"
echo "Для этого нажми на иконку папки в лаунчере и скопируй путь из проводника"
read -p "(в конце должно быть что-то типо .minecraft или game): " MCDIR

if [ -z "$MCDIR" ]; then
  MCDIR=~/.minecraft
fi

GAMEDIR=~/.minecraft-bta
JSON=$MCDIR/versions/BTA-Babric-7.3_03/BTA-Babric-7.3_03.json

if [ -d "$MCDIR/libraries" ]; then
  rm -rf "$MCDIR/libraries"
fi

if [ -f "$GAMEDIR/mods/halplibe-5.1.2.jar" ]; then
  rm "$GAMEDIR/mods/halplibe-5.1.2.jar"
fi

if [ -f "$GAMEDIR/mods/modmenu-bta-2.0.5.jar" ]; then
  rm "$GAMEDIR/mods/modmenu-bta-2.0.5.jar"
fi

if [ -f "$GAMEDIR/mods/times-1.1.2.jar" ]; then
  rm "$GAMEDIR/mods/times-1.1.2.jar"
fi

cp -r .minecraft-bta "$GAMEDIR"

cp -r --parents BTA-Babric-7.3_03 "$MCDIR/versions/"

#sed -i -e "s/\${game_directory}/${GAMEDIR}/g" "${JSON}"
sed -i -e "s/\${game_directory}/$(echo "${GAMEDIR}" | sed 's/\\/\\\\/g; s/\//\\\//g')/g" "${JSON}"

echo "УСПЕХ!"
echo "Теперь нажать кнопку обновить справа в TLauncher и выбрать версию BTA-Babric-7.3_03 слева"
echo "(нужно пролистать вниз до конца или до beta 1.7.3)"
read -p "Press Enter to continue..."

