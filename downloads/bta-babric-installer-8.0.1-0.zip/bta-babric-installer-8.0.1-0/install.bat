@echo off
@chcp 65001 > nul

echo Нажми Enter если у тебя TLauncher
echo Иначе, укажи путь до майнкрафта:
echo Для этого нажми на иконку папки в лаунчере и скопируй путь из проводника
set /p MCDIR=(в конце должно быть что-то типо .minecraft или game): 

if "%MCDIR%" == "" set MCDIR=%USERPROFILE%\AppData\Roaming\.minecraft

set GAMEDIR=%APPDATA:\=\\%\\.minecraft-bta\\
set JSON=%MCDIR%\versions\BTA-Babric-8.0.1\BTA-Babric-8.0.1.json

IF EXIST "%MCDIR%\libraries\" (
    for /d /r "%MCDIR%\libraries" %%i in (*) do rmdir /s /q "%%i"
)
)
IF EXIST "%GAMEDIR:\\=\%mods\halplibe-5.2.4.jar" (
    DEL /F /Q "%GAMEDIR:\\=\%mods\halplibe-5.2.4.jar"
)
IF EXIST "%GAMEDIR:\\=\%mods\modmenu-bta-3.0.0.jar" (
    DEL /F /Q "%GAMEDIR:\\=\%mods\modmenu-bta-2.0.5.jar"
)
IF EXIST "%GAMEDIR:\\=\%mods\times-1.2.1-7.3.jar" (
    DEL /F /Q "%GAMEDIR:\\=\%mods\times-1.1.2.jar"
)
IF EXIST "%GAMEDIR:\\=\%mods\writingsheets-1.1.0-7.3_01.jar" (
    DEL /F /Q "%GAMEDIR:\\=\%mods\writingsheets-1.1.0-7.3_01.jar"
)

xcopy /y /s ".\.minecraft-bta" "%GAMEDIR%"

xcopy /y /s ".\BTA-Babric-8.0.1" "%MCDIR%\versions\BTA-Babric-8.0.1\"

powershell -Command "(Get-Content -Path '%JSON%' -Raw) -replace '\${game_directory}', '%GAMEDIR%' | Set-Content -Path '%JSON%' -Encoding UTF8"


cls
echo УСПЕХ!
echo Теперь нажать кнопку обновить справа в TLauncher и выбрать версию BTA-Babric-8.0.1 слева
echo (нужно пролистать вниз до конца или до beta 1.7.3)
pause