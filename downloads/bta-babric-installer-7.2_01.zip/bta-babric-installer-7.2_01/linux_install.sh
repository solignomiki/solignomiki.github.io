#!/bin/bash

echo "Нажми Enter если у тебя TLauncher"
echo "Иначе, укажи путь до майнкрафта:"
echo "Для этого нажми на иконку папки в лаунчере и скопируй путь из проводника"
read -p "(в конце должно быть что-то типо .minecraft или game): " MCDIR

if [ -z "$MCDIR" ]; then
  MCDIR=~/.minecraft
fi

GAMEDIR=~/.minecraft-bta
JSON=$MCDIR/versions/BTA-Babric-7.2_01/BTA-Babric-7.2_01.json

if [ -d "$MCDIR/libraries" ]; then
  rm -rf "$MCDIR/libraries"
fi

if [ -f "$GAMEDIR/mods/btwaila-1.0.10-7.1.jar" ]; then
  rm "$GAMEDIR/mods/btwaila-1.0.10-7.1.jar"
fi

if [ -f "$GAMEDIR/mods/halplibe-3.5.4.jar" ]; then
  rm "$GAMEDIR/mods/halplibe-3.5.4.jar"
fi

if [ -f "$GAMEDIR/mods/modmenu-bta-2.0.5.jar" ]; then
  rm "$GAMEDIR/mods/modmenu-bta-2.0.5.jar"
fi

cp -r .minecraft-bta "$GAMEDIR"

if [ -d "$MCDIR/versions/BTA-Babric-7.2_01" ]; then
  rm -rf "$MCDIR/versions/BTA-Babric-7.2_01"
fi

cp -r --parents BTA-Babric-7.2_01 "$MCDIR/versions/"

#sed -i -e "s/\${game_dir}/${GAMEDIR}/g" "${JSON}"
sed -i -e "s/\${game_dir}/$(echo "${GAMEDIR}" | sed 's/\\/\\\\/g; s/\//\\\//g')/g" "${JSON}"

echo "УСПЕХ!"
echo "Теперь нажать кнопку обновить справа в TLauncher и выбрать версию BTA-Babric-7.2_01 слева"
echo "(нужно пролистать вниз до конца или до beta 1.7.3)"
read -p "Press Enter to continue..."

